import { getAccess } from "@/lib/access";
import { redirect } from "next/navigation";
import V5FeatureCenter from "@/components/V5FeatureCenter";
import PaymentMethodsV5 from "@/components/PaymentMethodsV5";

export default async function V5Page() {
  const access = await getAccess();
  if (!access.user) redirect("/login");
  return <div className="space-y-6"><div><h1 className="text-2xl font-extrabold">🚀 Wesh Star IA V5</h1><p className="mt-1 text-sm text-zinc-400">Nouvelle architecture fonctionnelle : production vidéo, heures, automatisation et paiements.</p></div><V5FeatureCenter /><PaymentMethodsV5 /></div>;
}
