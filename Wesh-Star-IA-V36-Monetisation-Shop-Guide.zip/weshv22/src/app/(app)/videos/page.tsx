import Link from "next/link";
import { getLang } from "@/lib/i18n";
import { getDictionary } from "@/lib/dictionaries";
import VideoGrid from "@/components/VideoGrid";
import { getSettings } from "@/lib/settings";

export default async function VideosPage() {
  const t = getDictionary(getLang());
  const settings = await getSettings();
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight">{t.nav_videos}</h1>
          <p className="mt-1 text-sm text-zinc-500">{t.my_videos_sub}</p>
        </div>
        <Link href="/generate" className="btn-primary btn-md">＋ {t.generate_new}</Link>
      </div>
      <VideoGrid t={t} communityEnabled={settings.site.communityEnabled || settings.site.socialNetworkEnabled} />
    </div>
  );
}
