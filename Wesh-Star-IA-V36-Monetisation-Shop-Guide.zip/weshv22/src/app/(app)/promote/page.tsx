import { redirect } from "next/navigation";
import { getAccess } from "@/lib/access";
import PromotionPanel from "@/components/PromotionPanel";

export default async function PromotePage() {
  const access = await getAccess();
  if (!access.user) redirect("/login");
  return <div className="space-y-5"><div><h1 className="text-2xl font-extrabold">📣 Sponsorisation</h1><p className="mt-1 text-sm text-zinc-500">Mets en avant tes vidéos publiques ou ton LIVE auprès de la communauté.</p></div><PromotionPanel /></div>;
}
