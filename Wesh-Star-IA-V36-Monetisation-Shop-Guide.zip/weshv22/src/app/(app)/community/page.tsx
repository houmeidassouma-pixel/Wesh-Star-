import { redirect, notFound } from "next/navigation";
import Link from "next/link";
import { getAccess } from "@/lib/access";
import { getSettings } from "@/lib/settings";
import { listCommunityPosts } from "@/lib/community";
import CommunityFeed from "@/components/CommunityFeed";
import AppAdRail from "@/components/AppAdRail";

export default async function CommunityPage({ searchParams }: { searchParams?: { post?: string } }) {
  const access = await getAccess();
  if (!access.user) redirect("/login");
  const settings = await getSettings();
  if (!settings.site.communityEnabled && !settings.site.socialNetworkEnabled) notFound();
  const requestedPost = typeof searchParams?.post === "string" ? searchParams.post.slice(0, 100) : undefined;
  const posts = await listCommunityPosts(access.user.id, "for-you", requestedPost);
  return <div className="space-y-6">
    <div className="flex flex-wrap items-end justify-between gap-3">
      <div>
        <div className="flex items-center gap-3"><h1 className="text-2xl font-extrabold">🌟 Wesh Star Feed</h1><span className="rounded-full bg-blue-500/10 px-2.5 py-1 text-[11px] font-bold text-blue-400">COMMUNAUTÉ</span></div>
        <p className="mt-1 text-sm text-zinc-500">Découvre, publie et partage les vidéos créées avec Wesh Star IA.</p>{requestedPost && <p className="mt-2 text-xs text-violet-300">Vidéo partagée · le contenu reste soumis aux paramètres de visibilité du créateur.</p>}
      </div>
      <Link href="/messages" className="btn-secondary inline-flex">✉ Messages privés</Link>
    </div>
    <CommunityFeed initialPosts={posts} currentUserId={access.user.id} adSlot={<AppAdRail />} adEveryPosts={settings.site.ads.feedAdEveryPosts} maxFeedAds={settings.site.ads.maxFeedAdsPerVisit} />
  </div>;
}
