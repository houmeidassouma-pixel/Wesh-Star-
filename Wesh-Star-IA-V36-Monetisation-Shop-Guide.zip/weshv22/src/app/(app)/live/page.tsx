import { redirect } from "next/navigation";
import { getAccess } from "@/lib/access";
import LiveRoom from "@/components/LiveRoom";

export default async function LivePage() {
  const access = await getAccess();
  if (!access.user) redirect("/login");
  return <div className="space-y-6"><div><h1 className="text-2xl font-extrabold">📡 LIVE</h1><p className="mt-1 text-sm text-zinc-500">Cadeaux et coffres en pièces Wesh, séparés des crédits vidéo.</p></div><LiveRoom /></div>;
}
