import { redirect } from "next/navigation";
import { getAccess } from "@/lib/access";
import PrivateMessagesPanel from "@/components/PrivateMessagesPanel";

export default async function MessagesPage() {
  const access = await getAccess();
  if (!access.user) redirect("/login");
  return <div className="space-y-5"><div><h1 className="text-2xl font-extrabold">Messages privés</h1><p className="mt-1 text-sm text-zinc-500">Échange avec les autres membres de Wesh Star IA.</p></div><PrivateMessagesPanel currentUserId={access.user.id} /></div>;
}
