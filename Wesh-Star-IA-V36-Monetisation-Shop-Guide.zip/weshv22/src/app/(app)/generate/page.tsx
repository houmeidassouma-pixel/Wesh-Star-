import { quotaPeriodKey } from "@/lib/quota-period";
import { getLang } from "@/lib/i18n";
import { getDictionary } from "@/lib/dictionaries";
import { getAccess } from "@/lib/access";
import GenerateStudio from "@/components/GenerateStudio";
import VideoEditor from "@/components/VideoEditor";
import CreatorStudio from "@/components/CreatorStudio";
import AutoMontage from "@/components/AutoMontage";
import ProductAdStudio from "@/components/ProductAdStudio";
import CreatorMonetizationCard from "@/components/CreatorMonetizationCard";
import { createAdminClient } from "@/lib/account/admin";
import Link from "next/link";

export default async function GeneratePage() {
  const t = getDictionary(getLang());
  const access = await getAccess();
  let availableSeconds = access.isAdmin ? access.maxSeconds : access.maxSeconds;

  if (access.user && !access.isAdmin && !access.isModerator) {
    const month = quotaPeriodKey(access.profile);
    const day = new Date().toISOString().slice(0, 10);
    const admin = createAdminClient();
    const { data: monthCounter } = await admin.from("usage_counters").select("seconds").eq("user_id", access.user.id).eq("period", month).maybeSingle();
    const { data: dayCounter } = await admin.from("usage_counters").select("seconds").eq("user_id", access.user.id).eq("period", day).maybeSingle();
    const monthRemaining = Math.max(0, Number(access.limits.monthlySeconds || 0) - Number(monthCounter?.seconds || 0));
    const dayRemaining = Math.max(0, Number(access.limits.dailySeconds || 0) - Number(dayCounter?.seconds || 0));
    // Regular users can generate videos up to 10 minutes; monthly/daily quotas remain separate.
    availableSeconds = Math.min(access.maxSeconds, 10 * 60, monthRemaining, dayRemaining);
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-extrabold tracking-tight">{t.nav_generate}</h1>
        <p className="mt-1 text-sm text-zinc-500">{t.studio_sub}</p>
      </div>
      <div className="rounded-xl border border-zinc-800 bg-zinc-900/30 p-3 text-sm text-zinc-400">
        Ta génération continue dans la file d’attente même si tu consultes une autre page. {access.settings.site.socialNetworkEnabled && <><span>Pendant le traitement, tu peux aussi </span><Link href="/community" className="font-semibold text-violet-300 hover:text-violet-200">regarder les vidéos de la communauté</Link><span>. </span></>}Choisis une durée de 10 secondes à 10 minutes maximum, selon ton quota disponible.
      </div>
      <GenerateStudio t={t} maxSeconds={access.isAdmin || access.isModerator ? access.maxSeconds : Math.min(access.maxSeconds, 10 * 60)} availableSeconds={availableSeconds} clipSeconds={access.settings.video.clipSeconds} />
      <CreatorMonetizationCard />
      <CreatorStudio />
      <AutoMontage />
      <VideoEditor />
      <ProductAdStudio />
    </div>
  );
}
