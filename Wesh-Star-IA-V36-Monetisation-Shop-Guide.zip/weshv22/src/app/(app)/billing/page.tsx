import { quotaPeriodKey } from "@/lib/quota-period";
import Link from "next/link";
import { getAccess } from "@/lib/access";
import { getSettings } from "@/lib/settings";
import BillingHistory from "@/components/BillingHistory";
import StripePortalButton from "@/components/StripePortalButton";
import { createAdminClient } from "@/lib/account/admin";

export default async function BillingPage() {
  const access = await getAccess();
  const settings = await getSettings();
  let planRemainingSeconds = 0;
  if (!access.isAdmin) {
    const month = quotaPeriodKey(access.profile);
    const { data: counter } = await createAdminClient().from("usage_counters").select("seconds").eq("user_id", access.user.id).eq("period", month).maybeSingle();
    planRemainingSeconds = Math.max(0, Number(access.limits.monthlySeconds || 0) - Number(counter?.seconds || 0));
  }
  const remainingTokens = access.isAdmin ? 0 : Math.floor(planRemainingSeconds / 10);
  const purchasedTokens = access.isAdmin ? 0 : Math.floor(Number(access.profile?.hour_credits_seconds || 0) / 10);
  const dynamicPlan = settings.plans.monthlyTiers.find((x) => x.id === access.planKey);
  const plan = access.isAdmin ? "ADMIN" : access.planKey === "free"
    ? "Gratuit" : String(dynamicPlan?.name || (settings.plans as any)[access.planKey]?.name || access.planKey);
  const planPrice = access.isAdmin || access.planKey === "free" ? 0 : Number(dynamicPlan?.price || (settings.plans as any)[access.planKey]?.price || 0);


  const fmt = (s:number) => s >= 3600 ? `${Math.floor(s/3600)} h ${Math.floor((s%3600)/60)} min` : s >= 60 ? `${Math.floor(s/60)} min` : `${s} s`;

  return <div className="space-y-8">
    <div className="flex flex-wrap items-center justify-between gap-3">
      <div><h1 className="text-2xl font-extrabold tracking-tight">💳 Abonnement et paiements</h1>
      <p className="mt-1 text-sm text-zinc-400">Gérez votre forfait, vos crédits vidéo et votre historique de paiements. Le renouvellement manuel est le choix par défaut ; les prélèvements automatiques n’existent que si vous les avez explicitement activés.</p></div>
      <div className="flex flex-wrap gap-2"><Link href="/pricing" className="btn-primary btn-md">Voir les forfaits et renouveler →</Link></div>
    </div>

    <div className="grid gap-4 md:grid-cols-3">
      <div className="card p-5"><div className="text-sm text-zinc-400">Abonnement actuel</div><div className="mt-2 text-xl font-bold">{plan}</div>{!access.isAdmin && access.planKey !== "free" && <div className="mt-1 text-sm text-zinc-400">{planPrice.toFixed(2)} € / mois de référence · {access.profile?.stripe_subscription_id ? "abonnement Stripe" : "renouvellement manuel"}</div>}
        {!access.isAdmin && <Link href="/pricing" className="mt-4 inline-flex btn-secondary btn-sm">Changer de plan</Link>}</div>
      <div className="card p-5"><div className="text-sm text-zinc-400">Crédits vidéo de génération restants</div>
        <div className="mt-2 text-xl font-bold">{access.isAdmin ? "∞" : `${remainingTokens} crédits vidéo`}</div>
        {!access.isAdmin && <div className="mt-1 text-xs text-zinc-500">Votre solde restant pour le cycle actuel · 1 minute = 6 crédits vidéo.</div>}
        {!access.isAdmin && <div className={`mt-2 text-xs font-semibold ${remainingTokens > 0 || purchasedTokens > 0 ? "text-green-400" : "text-amber-400"}`}>{remainingTokens > 0 || purchasedTokens > 0 ? "✓ Crédits disponibles" : "⚠ Crédits épuisés — choisissez un forfait ou achetez des crédits"}</div>}
        {!access.isAdmin && <Link href="/pricing" className="mt-4 inline-flex btn-primary btn-sm">Voir les forfaits vidéo</Link>}</div>
      <div className="card p-5"><div className="text-sm text-zinc-400">Crédits vidéo achetés en supplément</div>
        <div className="mt-2 text-xl font-bold">{access.isAdmin ? "∞" : `${purchasedTokens} crédits vidéo`}</div>
        <div className="mt-1 text-xs text-zinc-500">Crédits achetés séparément de votre quota mensuel</div></div>
      <div className="card p-5"><div className="text-sm text-zinc-400">Crédits vidéo du plan</div>
        <div className="mt-2 text-xl font-bold">{access.isAdmin ? "∞" : `${Math.floor(access.limits.monthlySeconds / 10)} crédits vidéo`}</div>
        <div className="mt-1 text-xs text-zinc-500">Crédits vidéo inclus dans votre abonnement mensuel</div></div>
    </div>

    {!access.isAdmin && access.profile?.stripe_customer_id && <div className="card p-5"><h2 className="font-bold">🔁 Gestion du prélèvement automatique</h2><p className="mt-1 mb-3 text-sm text-zinc-400">Si vous avez coché l’option d’abonnement mensuel automatique, vous pouvez gérer ou annuler les prochains prélèvements ici. Les paiements uniques ne sont pas concernés.</p><StripePortalButton /></div>}

    {!access.isAdmin && <div className="card border-banana/10 bg-banana/5 p-5">
      <h2 className="font-bold">Besoin de plus de crédits vidéo ?</h2>
      <p className="mt-1 text-sm text-zinc-400">Choisissez un abonnement mensuel avec le nombre de crédits vidéo dont vous avez besoin depuis la page des tarifs.</p>
      <Link href="/pricing" className="mt-4 inline-flex btn-primary btn-md">Gérer mes crédits vidéo →</Link>
    </div>}

    <div className="card p-5"><h2 className="text-lg font-bold">📄 Historique des paiements et reçus</h2>
      <p className="mt-1 text-sm text-zinc-400">Références, montants, types et statuts des paiements de votre compte.</p>
      <BillingHistory />
    </div>
  </div>;
}
