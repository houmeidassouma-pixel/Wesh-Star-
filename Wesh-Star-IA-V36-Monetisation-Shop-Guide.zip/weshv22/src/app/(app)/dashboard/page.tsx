import { quotaPeriodKey } from "@/lib/quota-period";
import Link from "next/link";
import { getLang } from "@/lib/i18n";
import { getDictionary } from "@/lib/dictionaries";
import { getAccess } from "@/lib/access";
import { createAdminClient } from "@/lib/account/admin";
import StatCard from "@/components/StatCard";
import VideoGrid from "@/components/VideoGrid";
import AdUnit from "@/components/AdUnit";

export default async function DashboardPage() {
  const t = getDictionary(getLang());
  const access = await getAccess();
  const admin = createAdminClient();

  const { count: total } = await admin
    .from("generations").select("id", { count: "exact", head: true }).eq("user_id", access.user!.id);

  // Exact remaining quota from the atomic counters (failed jobs are refunded)
  let used = 0, usedSeconds = 0;
  if (!access.isAdmin) {
    const month = quotaPeriodKey(access.profile);
    const { data: counter } = await admin
      .from("usage_counters")
      .select("count, seconds")
      .eq("user_id", access.user!.id)
      .eq("period", month)
      .maybeSingle();
    used = counter?.count ?? 0;
    usedSeconds = Number(counter?.seconds ?? 0);
  }

  const purchasedCreditSeconds = access.isAdmin ? 0 : Number(access.profile?.hour_credits_seconds || 0);
  const purchasedTokens = Math.floor(purchasedCreditSeconds / 10);
  const remaining = access.isAdmin ? "∞" : Math.max(0, access.monthlyJobs - used);
  const remainingSeconds = access.isAdmin ? 0 : Math.max(0, access.limits.monthlySeconds - usedSeconds);
  const dynamicLabel = access.planKey !== "free" ? access.settings.plans.monthlyTiers.find((x) => x.id === access.planKey)?.name : null;
  const planLabel = access.isAdmin
    ? "ADMIN"
    : access.planKey === "free" ? t.plan_free : (dynamicLabel || t["plan_" + access.planKey] || access.planKey);

  return (
    <div className="space-y-8">
      <div className="flex flex-wrap items-center gap-3">
        <h1 className="text-2xl font-extrabold tracking-tight">{t.nav_overview}</h1>
        <span className={access.isAdmin ? "badge-yellow" : "badge-zinc"}>{planLabel}</span>
      </div>

      <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        <StatCard icon="🎬" label={t.total_videos} value={total ?? 0} delay={0} />
        <StatCard icon="🪙" label="Crédits vidéo restants" value={access.isAdmin ? "∞" : Math.floor(remainingSeconds / 10) + " crédits vidéo"} hint={access.isAdmin ? t.unlimited : "Solde disponible ce mois"} delay={0.05} />
        <StatCard icon="📊" label="Crédits vidéo utilisés" value={access.isAdmin ? "∞" : Math.floor(usedSeconds / 10) + " crédits vidéo"} hint={access.isAdmin ? "Illimité" : `${used} vidéos générées ce mois`} delay={0.1} />
        <StatCard icon="🎁" label="Crédits vidéo achetés" value={access.isAdmin ? "∞" : purchasedTokens + " crédits vidéo"} hint={access.isAdmin ? "Illimité" : "Crédits supplémentaires"} delay={0.15} />
      </div>

      {!access.isAdmin && purchasedTokens > 0 && (
        <div className="card animate-fade-up border-banana/10 bg-banana/5 p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div><h3 className="font-bold">🪙 Crédits vidéo achetés</h3><p className="mt-1 text-sm text-zinc-400">Vous avez <b className="text-white">{purchasedTokens} crédits vidéo</b> supplémentaires achetés. Ils sont utilisés lorsque votre quota de plan ne suffit pas.</p></div>
            <Link href="/billing" className="btn-secondary btn-sm">Voir mes crédits →</Link>
          </div>
        </div>
      )}

      {!access.isAdmin && (
        <div className="card animate-fade-up border-zinc-800 p-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div><h3 className="font-bold">🪙 Utilisation des crédits vidéo</h3><p className="mt-1 text-sm text-zinc-400">{Math.floor(usedSeconds / 10)} crédits vidéo utilisés ce mois · il vous reste {Math.floor(remainingSeconds / 10)} crédits vidéo.</p></div>
            <Link href="/billing" className="btn-secondary btn-sm">Gérer mes crédits vidéo →</Link>
          </div>
        </div>
      )}

      {!access.isAdmin && access.planKey !== "pro" && (
        <div className="card animate-fade-up flex flex-wrap items-center justify-between gap-4 border-banana/10 bg-gradient-to-r from-banana/10 to-transparent p-5">
          <div>
            <h3 className="font-bold">⭐ {t.upgrade_pro_title}</h3>
            <p className="mt-1 text-sm text-zinc-400">{t.upgrade_pro_text}</p>
          </div>
          <Link href="/pricing" className="btn-primary btn-md">{t.upgrade} →</Link>
        </div>
      )}

      <AdUnit context="dashboard video creation AI Wesh Star IA" />

      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">{t.your_videos}</h2>
        <Link href="/generate" className="btn-primary btn-sm">＋ {t.generate_new}</Link>
      </div>
      <VideoGrid t={t} />
    </div>
  );
}
