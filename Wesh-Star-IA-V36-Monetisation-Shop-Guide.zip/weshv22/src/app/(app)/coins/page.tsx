import { redirect } from "next/navigation";
import { getAccess } from "@/lib/access";
import CoinWalletPanel from "@/components/CoinWalletPanel";
export default async function CoinsPage() {
  const access = await getAccess();
  if (!access.user) redirect("/login");
  return <div className="space-y-6"><div><h1 className="text-2xl font-extrabold">🪙 Pièces Wesh Star IA</h1><p className="mt-1 text-sm text-zinc-500">Acheter des pièces pour envoyer des cadeaux.</p></div><CoinWalletPanel /></div>;
}
