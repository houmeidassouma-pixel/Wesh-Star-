import { getLang } from "@/lib/i18n";
import { getDictionary } from "@/lib/dictionaries";
import { getAccess } from "@/lib/access";
import PasswordForm from "@/components/PasswordForm";
import Link from "next/link";
import AdControls from "@/components/AdControls";
import DataSaverSettings from "@/components/DataSaverSettings";

export default async function SettingsPage() {
  const t = getDictionary(getLang());
  const access = await getAccess();

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-extrabold tracking-tight">{t.nav_settings}</h1>

      <div className="card animate-fade-up p-6">
        <h2 className="font-bold">{t.account}</h2>
        <dl className="mt-4 grid gap-4 text-sm sm:grid-cols-3">
          <div>
            <dt className="label">{t.email}</dt>
            <dd>{access.user!.email}</dd>
          </div>
          <div>
            <dt className="label">{t.current_plan}</dt>
            <dd>
              <span className={access.isAdmin ? "badge-yellow" : "badge-zinc"}>
                {access.isAdmin ? "ADMIN" : access.planKey === "free" ? t.plan_free : (access.settings.plans.monthlyTiers.find((x) => x.id === access.planKey)?.name || t["plan_" + access.planKey] || access.planKey)}
              </span>
            </dd>
          </div>
          <div>
            <dt className="label">{t.member_since}</dt>
            <dd className="text-zinc-400">{new Date(access.profile?.created_at || Date.now()).toLocaleDateString()}</dd>
          </div>
        </dl>
      </div>

      <div className="card flex flex-wrap items-center justify-between gap-4 p-5">
        <div><h2 className="font-bold">💳 Facturation et abonnement</h2>
        <p className="mt-1 text-sm text-zinc-400">Voir vos crédits vidéo, paiements et reçus, et gérer votre abonnement.</p></div>
        <Link href="/billing" className="btn-primary btn-md">Ouvrir la facturation →</Link>
      </div>
      <DataSaverSettings />
      <AdControls />
      <PasswordForm t={t} />
    </div>
  );
}
