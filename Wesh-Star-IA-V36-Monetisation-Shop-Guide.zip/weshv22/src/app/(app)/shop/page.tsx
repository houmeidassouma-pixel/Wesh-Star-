import ShopMarketplace from "@/components/ShopMarketplace";

export default function ShopPage() {
  return <ShopMarketplace />;
}
