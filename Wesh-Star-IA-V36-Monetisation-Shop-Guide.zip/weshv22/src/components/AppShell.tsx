"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { locales, localeNames } from "@/lib/dictionaries";
import LogoutButton from "./LogoutButton";

export default function AppShell({ t, lang, email, role, siteName, logoUrl, logoEmoji = "⭐", communityEnabled = false, socialNetworkEnabled = false, remainingSeconds, purchasedCreditSeconds = 0, children }: any) {
  const pathname = usePathname();
  const router = useRouter();
  const [open, setOpen] = useState(false);

  useEffect(() => { setOpen(false); }, [pathname]);

  const setLang = (v: string) => {
    document.cookie = "lang=" + v + ";path=/;max-age=31536000";
    router.refresh();
  };

  const items = [
    { href: "/dashboard", icon: "📊", label: t.nav_overview },
    { href: "/generate", icon: "🎬", label: t.nav_generate },
    { href: "/videos", icon: "🎞️", label: t.nav_videos },
    { href: "/promote", icon: "📣", label: "Sponsoriser" },
    { href: "/shop", icon: "🛍️", label: "Wesh Star Shop" },
    { href: "/messages", icon: "💬", label: "Messages privés" },
    { href: "/pricing", icon: "💎", label: t.nav_subscription },
    { href: "/billing", icon: "💳", label: t.billing_nav || "Abonnement & paiements" },
    { href: "/coins", icon: "🪙", label: "Pièces & cadeaux" },
    { href: "/settings", icon: "⚙️", label: t.nav_settings },
    { href: "/v5", icon: "🚀", label: t.v5_nav || "Wesh Star IA V5" }
  ];
  if (communityEnabled || socialNetworkEnabled) items.push({ href: "/community", icon: "🌟", label: "Wesh Star Feed" });
  if (communityEnabled || socialNetworkEnabled) items.push({ href: "/live", icon: "📡", label: "LIVE" });
  if (role === "admin") {
    items.push({ href: "/admin", icon: "🛡️", label: t.admin });
  }
  if (role === "admin" || role === "moderator") {
    items.push({ href: "/moderator", icon: "🔍", label: t.nav_moderation });
  }

  const nav = (onNavigate?: () => void) => (
    <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-4">
      {items.map((item) => {
        const active = pathname === item.href || (item.href !== "/dashboard" && pathname.startsWith(item.href));
        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={onNavigate}
            className={
              "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-all " +
              (active
                ? "bg-banana/10 text-banana shadow-inner"
                : "text-zinc-400 hover:bg-zinc-900 hover:text-zinc-100")
            }
          >
            <span>{item.icon}</span>
            {item.label}
            {item.href === "/admin" && <span className="badge-yellow ml-auto">ADMIN</span>}
          </Link>
        );
      })}
    </nav>
  );

  const userCard = (
    <div className="border-t border-zinc-800/70 p-3">
      <Link href="/billing" className="mb-2 flex items-center justify-between rounded-xl border border-zinc-800 bg-zinc-900/60 px-3 py-2 text-xs hover:border-banana/40">
        <span className="text-zinc-400">🪙 Crédits vidéo restants</span>
        <span className="font-bold text-banana">{remainingSeconds === null ? "∞" : `${Math.floor(Number(remainingSeconds || 0) / 10)} crédits vidéo`}</span>
      </Link>
      {remainingSeconds !== null && Number(purchasedCreditSeconds || 0) > 0 && (
        <Link href="/billing" className="mb-2 flex items-center justify-between rounded-xl border border-banana/20 bg-banana/5 px-3 py-2 text-xs hover:border-banana/40">
          <span className="text-zinc-400">🪙 Crédits vidéo achetés</span>
          <span className="font-bold text-banana">{Math.floor(Number(purchasedCreditSeconds || 0) / 10)} crédits vidéo</span>
        </Link>
      )}
      <div className="card flex items-center gap-2 p-2.5">
        <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-zinc-800 text-sm">👤</span>
        <span className="min-w-0 flex-1 truncate text-xs text-zinc-400">{email}</span>
        <LogoutButton label="⏻" />
      </div>
    </div>
  );

  const brand = (
    <Link href="/" className="flex h-16 items-center gap-2 border-b border-zinc-800/70 px-4">
      <span className="grid h-9 w-9 place-items-center overflow-hidden rounded-xl bg-gradient-to-br from-banana to-yellow-600 text-lg shadow-lg shadow-banana/20">{logoUrl ? <img src={logoUrl} alt="Logo" className="h-full w-full object-contain" /> : logoEmoji}</span>
      <span className="font-extrabold tracking-tight">{siteName || t.site_name}</span>
    </Link>
  );

  return (
    <div className="flex min-h-screen">
      {/* Desktop sidebar */}
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r border-zinc-800/70 bg-zinc-950/90 lg:flex">
        {brand}
        {nav()}
        {userCard}
      </aside>

      {/* Mobile topbar */}
      <div className="fixed inset-x-0 top-0 z-40 flex h-14 items-center justify-between border-b border-zinc-800/70 bg-zinc-950/90 px-4 backdrop-blur-xl lg:hidden">
        <button className="btn-ghost btn-md" onClick={() => setOpen(!open)} aria-label="Menu">
          {open ? "✕" : "☰"}
        </button>
        <Link href="/" className="flex items-center gap-2">
          <span className="grid h-8 w-8 place-items-center overflow-hidden rounded-lg bg-gradient-to-br from-banana to-yellow-600 text-base">{logoUrl ? <img src={logoUrl} alt="Logo" className="h-full w-full object-contain" /> : logoEmoji}</span>
          <span className="font-extrabold">{siteName || t.site_name}</span>
        </Link>
        <select
          value={lang}
          onChange={(e) => setLang(e.target.value)}
          aria-label={t.language}
          className="rounded-lg border border-zinc-800 bg-zinc-900 px-1 py-1.5 text-xs text-zinc-400"
        >
          {locales.map((l) => <option key={l} value={l}>{localeNames[l]}</option>)}
        </select>
      </div>

      {/* Mobile drawer */}
      {open && (
        <div className="animate-fade-in fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/60" onClick={() => setOpen(false)} />
          <aside className="absolute inset-y-0 left-0 flex w-72 flex-col border-r border-zinc-800 bg-zinc-950">
            {brand}
            {nav(() => setOpen(false))}
            {userCard}
          </aside>
        </div>
      )}

      {/* Six-item mobile social navigation; Studio IA is added alongside the five existing actions. */}
      {socialNetworkEnabled && (
        <nav aria-label="Navigation mobile" className="fixed inset-x-0 bottom-0 z-40 grid grid-cols-6 border-t border-zinc-800 bg-zinc-950/95 px-1 pb-[env(safe-area-inset-bottom)] pt-2 backdrop-blur-xl lg:hidden">
          {[
            { href: "/community", icon: "⌂", label: "Accueil" },
            { href: "/videos", icon: "◉", label: "Découvrir" },
            { href: "/videos", icon: "+", label: "Créer" },
            { href: "/generate", icon: "✦", label: "Studio IA" },
            { href: "/messages", icon: "▤", label: "Messages" },
            { href: "/settings", icon: "♙", label: "Profil" }
          ].map((item) => {
            const active = pathname === item.href || (item.href !== "/community" && pathname.startsWith(item.href));
            return <Link key={item.label} href={item.href} className={`flex min-w-0 flex-col items-center justify-center gap-1 rounded-lg px-0.5 py-1 text-[10px] ${active ? "text-violet-300" : "text-zinc-400"}`}>
              <span className={`grid h-7 min-w-7 place-items-center rounded-xl text-lg ${item.label === "Studio IA" ? "bg-gradient-to-r from-blue-600 to-violet-600 px-2 text-white shadow-lg shadow-violet-900/30" : ""}`}>{item.icon}</span>
              <span className="truncate">{item.label}</span>
            </Link>;
          })}
        </nav>
      )}

      {/* Content */}
      <div className={`flex-1 px-4 ${socialNetworkEnabled ? "pb-24" : "pb-10"} pt-20 md:px-8 lg:pb-10 lg:pl-64 lg:pt-8`}>
        <div className="mx-auto max-w-5xl animate-fade-up">{children}</div>
      </div>
    </div>
  );
}
